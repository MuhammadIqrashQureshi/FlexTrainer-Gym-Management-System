﻿namespace Member_Forms
{
    partial class Admin_Interface
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Admin_Interface));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.mEMBERSHIPSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tRAINERSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mEMBERSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pERFORMANCEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rEQUESTSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lOGOUTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.menuStrip1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(30, 30);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mEMBERSHIPSToolStripMenuItem,
            this.tRAINERSToolStripMenuItem,
            this.mEMBERSToolStripMenuItem,
            this.pERFORMANCEToolStripMenuItem,
            this.rEQUESTSToolStripMenuItem,
            this.reportsToolStripMenuItem,
            this.lOGOUTToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(63, 7);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(4, 2, 0, 2);
            this.menuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.menuStrip1.Size = new System.Drawing.Size(894, 38);
            this.menuStrip1.Stretch = false;
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // mEMBERSHIPSToolStripMenuItem
            // 
            this.mEMBERSHIPSToolStripMenuItem.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.mEMBERSHIPSToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ScrollBar;
            this.mEMBERSHIPSToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("mEMBERSHIPSToolStripMenuItem.Image")));
            this.mEMBERSHIPSToolStripMenuItem.Name = "mEMBERSHIPSToolStripMenuItem";
            this.mEMBERSHIPSToolStripMenuItem.Size = new System.Drawing.Size(128, 34);
            this.mEMBERSHIPSToolStripMenuItem.Text = "MEMBERSHIPS";
            this.mEMBERSHIPSToolStripMenuItem.Click += new System.EventHandler(this.mEMBERSHIPSToolStripMenuItem_Click);
            // 
            // tRAINERSToolStripMenuItem
            // 
            this.tRAINERSToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ScrollBar;
            this.tRAINERSToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("tRAINERSToolStripMenuItem.Image")));
            this.tRAINERSToolStripMenuItem.Name = "tRAINERSToolStripMenuItem";
            this.tRAINERSToolStripMenuItem.Size = new System.Drawing.Size(101, 34);
            this.tRAINERSToolStripMenuItem.Text = "TRAINERS";
            this.tRAINERSToolStripMenuItem.Click += new System.EventHandler(this.tRAINERSToolStripMenuItem_Click);
            // 
            // mEMBERSToolStripMenuItem
            // 
            this.mEMBERSToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ScrollBar;
            this.mEMBERSToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("mEMBERSToolStripMenuItem.Image")));
            this.mEMBERSToolStripMenuItem.Name = "mEMBERSToolStripMenuItem";
            this.mEMBERSToolStripMenuItem.Size = new System.Drawing.Size(103, 34);
            this.mEMBERSToolStripMenuItem.Text = "MEMBERS";
            this.mEMBERSToolStripMenuItem.Click += new System.EventHandler(this.mEMBERSToolStripMenuItem_Click);
            // 
            // pERFORMANCEToolStripMenuItem
            // 
            this.pERFORMANCEToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ScrollBar;
            this.pERFORMANCEToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("pERFORMANCEToolStripMenuItem.Image")));
            this.pERFORMANCEToolStripMenuItem.Name = "pERFORMANCEToolStripMenuItem";
            this.pERFORMANCEToolStripMenuItem.Size = new System.Drawing.Size(133, 34);
            this.pERFORMANCEToolStripMenuItem.Text = "PERFORMANCE";
            this.pERFORMANCEToolStripMenuItem.Click += new System.EventHandler(this.pERFORMANCEToolStripMenuItem_Click);
            // 
            // rEQUESTSToolStripMenuItem
            // 
            this.rEQUESTSToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ScrollBar;
            this.rEQUESTSToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("rEQUESTSToolStripMenuItem.Image")));
            this.rEQUESTSToolStripMenuItem.Name = "rEQUESTSToolStripMenuItem";
            this.rEQUESTSToolStripMenuItem.Size = new System.Drawing.Size(103, 34);
            this.rEQUESTSToolStripMenuItem.Text = "REQUESTS";
            this.rEQUESTSToolStripMenuItem.Click += new System.EventHandler(this.rEQUESTSToolStripMenuItem_Click);
            // 
            // lOGOUTToolStripMenuItem
            // 
            this.lOGOUTToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ScrollBar;
            this.lOGOUTToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("lOGOUTToolStripMenuItem.Image")));
            this.lOGOUTToolStripMenuItem.Name = "lOGOUTToolStripMenuItem";
            this.lOGOUTToolStripMenuItem.Size = new System.Drawing.Size(98, 34);
            this.lOGOUTToolStripMenuItem.Text = "LOG OUT";
            this.lOGOUTToolStripMenuItem.Click += new System.EventHandler(this.lOGOUTToolStripMenuItem_Click);
            // 
            // reportsToolStripMenuItem
            // 
            this.reportsToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.reportsToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ScrollBar;
            this.reportsToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("reportsToolStripMenuItem.Image")));
            this.reportsToolStripMenuItem.Name = "reportsToolStripMenuItem";
            this.reportsToolStripMenuItem.Size = new System.Drawing.Size(102, 34);
            this.reportsToolStripMenuItem.Text = "Reports";
            this.reportsToolStripMenuItem.Click += new System.EventHandler(this.reportsToolStripMenuItem_Click);
            // 
            // Admin_Interface
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(871, 450);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Admin_Interface";
            this.Text = "Admin_Interface";
            this.Load += new System.EventHandler(this.Admin_Interface_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem rEQUESTSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mEMBERSHIPSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tRAINERSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mEMBERSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pERFORMANCEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lOGOUTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportsToolStripMenuItem;
    }
}